"use client";
import React from "react";

function MainComponent() {
  return (
    <div className="min-h-screen bg-black text-[#8b0000] font-bold">
      {/* رأس الصفحة */}
      <header className="bg-[#1a0000] fixed w-full top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center">
            {/* الشعار الجديد */}
            <img
              src="https://ucarecdn.com/09cd71ba-2407-4090-b3b1-c936257d04ec/-/format/auto/"
              alt="Ben'Khaled Logo"
              className="h-10 w-auto"
              style={{
                filter:
                  "brightness(0) saturate(100%) invert(11%) sepia(82%) saturate(3421%) hue-rotate(356deg) brightness(96%) contrast(114%)",
              }}
            />
          </div>

          <nav className="hidden md:block">
            <ul className="flex space-x-8 items-center text-lg">
              <li>
                <a href="/" className="text-[#8b0000] hover:text-[#660000]">
                  الرئيسية
                </a>
              </li>
              <li>
                <a
                  href="/rules"
                  className="text-[#8b0000] hover:text-[#660000]"
                >
                  القوانين
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-[#8b0000] hover:text-[#660000] flex items-center"
                >
                  <span>ربط الديسكورد</span>
                  <img
                    src="https://assets-global.website-files.com/6257adef93867e50d84d30e2/636e0a6a49cf127bf92de1e2_icon_clyde_blurple_RGB.png"
                    alt="Discord"
                    className="w-5 h-5 ml-2"
                    style={{
                      filter:
                        "brightness(0) saturate(100%) invert(11%) sepia(82%) saturate(3421%) hue-rotate(356deg) brightness(96%) contrast(114%)",
                    }}
                  />
                </a>
              </li>
            </ul>
          </nav>

          <div>
            <button className="bg-[#8b0000] text-white px-6 py-2 rounded hover:bg-[#660000] transition text-lg">
              تسجيل دخول
            </button>
          </div>
        </div>
      </header>

      {/* المحتوى الرئيسي */}
      <main className="pt-20">
        {/* قسم البطل */}
        <section
          className="relative h-screen flex items-center justify-center text-center"
          style={{
            backgroundImage:
              'linear-gradient(rgba(0,0,0,0.7), rgba(139,0,0,0.3)), url("https://images.unsplash.com/photo-1533134486753-c833f0ed4866?ixlib=rb-4.0.3")',
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        >
          <div className="max-w-4xl mx-auto px-6">
            <img
              src="https://ucarecdn.com/0c8073c0-77ab-44c5-8ade-a0a55c249048/-/format/auto/"
              alt="Ben'Khaled Family"
              className="w-full max-w-3xl mx-auto mb-8"
              style={{ filter: "drop-shadow(0 0 20px rgba(139,0,0,0.5))" }}
            />
            <button className="bg-[#8b0000] text-white px-8 py-3 rounded-lg text-xl hover:bg-[#660000] transition">
              العب الآن
            </button>
          </div>
        </section>
      </main>
    </div>
  );
}

export default MainComponent;